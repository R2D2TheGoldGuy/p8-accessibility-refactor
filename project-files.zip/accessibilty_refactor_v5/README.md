# 3_Accessibility_Refactor
Take a set of interlinked pages that suffer from various accessibility flaws and refine and update them so they are accessible and pass an accessibility validator(s)'s automated checks and a human's check.

Font used: https://www.google.com/fonts/specimen/Montserrat
